function Footer() {

    return `<footer class="mb-4 text-center text-white">
    <!-- Grid container -->
    <div class="container pt-3 pb-0">

      <div class="text-center text-dark">
      © 2022 Copyright:  Flamencotech.com
    </div>
    </div>
    <!-- Grid container -->

  </footer>`
  
  
  }
  export { Footer};